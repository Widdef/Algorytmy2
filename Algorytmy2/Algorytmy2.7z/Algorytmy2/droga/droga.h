#pragma once
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>


void menu_25();
void rozmiar(int*);
void generuj(int***, int*, int);
void wyswietl_25(int**, int**,int);
void wyswietl_matrix(int**,int);
void solve(int**, const int, int);