#pragma once
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

void menu_21();
void swap(int*, int*);
void babelkowe(int[],int, int*, int*);
void wstawianie(int[], int, int*, int*);
void shella(int[], int, int*, int*);
int partition(int[], int, int, int*, int*);
void quicksort(int[], int, int, int*, int*);