#pragma once
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void menu_22();
void swapkop(char*, char*);
void heap(char*, int, int);
void heapSort(char*, int);